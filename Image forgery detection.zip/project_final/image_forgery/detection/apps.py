from django.apps import AppConfig


class DetectionConfig(AppConfig):
    name = 'detection'
