import os
import smtplib
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from detection.models import UserRegistration, UserLogin, UserImage, Feedback, Results, ImageDetails
from image_forgery.settings import BASE_DIR


# Create your views here.
def index(request):
    return render(request,'index.html')


def insertreg(request):
    if request.method == "POST":
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        s6 = request.POST.get('t6', '')
        if s5==s6:
            UserRegistration.objects.create(name=s1, address=s2, phone=s3, email=s4,   password=s5)
            UserLogin.objects.create(username=s4, password=s5, utype="user")
        return render(request, 'registration.html', context={'msg': 'registration successfull'})
    return render(request, 'registration.html')


def logcheck(request):
    if request.method == "POST":
        uname = request.POST.get('t1', '')
        request.session['username'] = uname
        pwd = request.POST.get('t2', '')
        checklogin = UserLogin.objects.filter(username=uname).values()
        for a in checklogin:
            utype = a['utype']
            upass = a['password']
            if (upass == pwd):
                if (utype == "admin"):
                    return render(request, 'admin_home.html')
                if (utype == "user"):
                    return render(request, 'user_home.html')
                else:
                    return render(request, 'login.html', context={'msg': 'check username or password'})
            return render(request, "login.html", context={'msg': 'check username or password'})
        return render(request, "login.html", context={'msg': 'check username or password'})
    return render(request, "login.html")


def forgotpassword(request):
    if request.method=="POST":
        uname = request.POST.get('t1', '')
        user = UserLogin.objects.filter(username=uname).count()
        if user >= 1:
            userlog = UserLogin.objects.filter(username=uname).values()
            for u in userlog:
                upass= u['password']
                content = upass
                mail = smtplib.SMTP('smtp.gmail.com', 587)
                mail.ehlo()
                mail.starttls()
                mail.login('bhavanabhat327@gmail.com', 'axkqsbuhlmbqjfbh')
                mail.sendmail('bhavanabhat327@gmail.com', uname , content)
                mail.close()
                return render(request,'login.html', {'msg': 'Your password has been sent to your E-mail'})
        else:
            return render(request,'forgotpassword.html', {'msg': 'Enter a valid username'})
    return render(request,'forgotpassword.html')


def fileupload(request):
    username = request.session['username']
    if request.method=="POST" and request.FILES['myfile']:
            name = request.POST.get('t1')
            myfile=request.FILES['myfile']
            date=request.POST.get('t2')
            details=request.POST.get('t4')
            type=request.POST.get('t3')
            fs = FileSystemStorage()
            filename = fs.save(myfile.name, myfile)
            uploaded_file_url = fs.url(filename)
            pat = os.path.join(BASE_DIR, '/media/' + filename)
            UserImage.objects.create(user_name=name,image_type=type,date=date,details=details,imglocation=myfile)
    return render(request,"fileupload.html",{'username':username})


def uchange_pass(request):
    username=request.session['username']
    if request.method=="POST":
        current_pass=request.POST.get("t1")
        new_pass=request.POST.get("t2")
        cofirm_pass=request.POST.get("t3")
        udata=UserLogin.objects.filter(username=username).filter(password=current_pass).count()
        if udata>=1:
            if new_pass==cofirm_pass:
                UserLogin.objects.filter(username=username).update(password=new_pass)
                return render(request,'user_home.html')
            else:
                return render(request,'change_user_pwd.html',context={'msg': 'check your old password'})
        else:
            return render(request, 'change_user_pwd.html',context={'msg': 'check your old password'})
    return render(request, 'change_user_pwd.html',{'username':username})


def viewresult(request):
    username = request.session['username']
    userdict = Results.objects.filter(by=username).values()
    return render(request, 'viewresult.html', {'userdict':userdict})


def feedback(request):
    if request.method == "POST":
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s4 = request.POST.get('t4', '')
        Feedback.objects.create(from_details=s1, to=s2, date=s3, details=s4)
        return render(request, 'feedback.html')
    return render(request, 'feedback.html')
# Admin menu pages


def userimagaes(request):
    userdict = UserImage.objects.all()
    return render(request, 'viewregistration.html', {'userdict': userdict})


def image_upload(request):
    if request.method=="POST" and request.FILES['myfile']:
            imgtype = request.POST.get('t1')
            imgname=request.POST.get('t2')
            myfile=request.FILES['myfile']
            details=request.POST.get('t3')
            date=request.POST.get('t4')
            by = request.POST.get('t5')
            fs = FileSystemStorage()
            filename = fs.save(myfile.name, myfile)
            uploaded_file_url = fs.url(filename)
            pat = os.path.join(BASE_DIR, '/media/' + filename)
            ImageDetails.objects.create(image_type=imgtype,image_name=imgname,image_location=myfile,details=details,created_date=date,created_by=by)
    return render(request,"imageupload.html")


def change_pass(request):
    username=request.session['username']
    if request.method=="POST":
        current_pass=request.POST.get("t1")
        new_pass=request.POST.get("t2")
        cofirm_pass=request.POST.get("t3")
        udata=UserLogin.objects.filter(username=username).filter(password=current_pass).count()
        if udata>=1:
            if new_pass==cofirm_pass:
                UserLogin.objects.filter(username=username).update(password=new_pass)
                return render(request,'admin_home.html')
            else:
                return render(request,'change_password.html',context={'msg': 'check your old password'})
        else:
            return render(request, 'change_password.html',context={'msg': 'check your old password'})
    return render(request, 'change_password.html',{'username':username})


def showuser(request):
    userdict = UserImage.objects.all()
    return render(request, 'viewregistration.html', {'userdict': userdict})


def selectimage(request,pk):
    oid=ImageDetails.objects.all()
    userdict = UserImage.objects.filter(id=pk).all()
    return render(request,'user_img_list.html',{'userdict': userdict,'oid':oid})


def showfeedback(request):
    userdict = Feedback.objects.all()
    return render(request, 'feedback_list.html', {'userdict': userdict})
